/* import 'package:some_package/some_package.dart';

class CustomSomeClass extends SomeClassFromPackage {
  @override
  void someMethod() {
    // Custom implementation
  }
}
*/