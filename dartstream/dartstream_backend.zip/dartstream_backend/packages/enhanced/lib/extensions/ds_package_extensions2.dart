/* import 'package:some_package/some_package.dart';

extension ExtendedFeature on SomeClassFromPackage {
  void newMethod() {
    // Your custom logic
  }
} */