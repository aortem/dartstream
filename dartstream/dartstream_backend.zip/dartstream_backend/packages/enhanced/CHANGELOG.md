# Changelog

## [0.0.1-pre] - 2024-05-11

### Added
- Initial release with enhanced features framework functionality.



