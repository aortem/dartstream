library ds_standard_extensions;

// Export standard extensions module
export 'ds_standard_web_extensions.dart';


// You can also include any shared utility functions or common interfaces here that might be used across multiple utility files.
