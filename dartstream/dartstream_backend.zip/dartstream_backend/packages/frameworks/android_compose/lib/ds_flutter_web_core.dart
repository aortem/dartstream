// lib/ds_standard_features.dart
library ds_standard_features_web;

//------------------ IMPORTS ---------------------------------

//The Standard Core Libraries - Built by the dart team

import 'package:web/web.dart';
import 'package:matcher/matcher.dart';

//------------------ EXPORTS ------------------

//The Standard Core Libraries - Built by the dart team

export 'package:web/web.dart';
export 'package:matcher/matcher.dart';
