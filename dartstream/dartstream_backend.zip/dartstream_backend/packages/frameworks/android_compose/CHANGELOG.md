# Changelog

## 0.0.1-pre+1 - 2024-08-12

- update web package to stable version 1.0.0.

## 0.0.1-pre - 2024-08-07

### Added
- Initial release with standard features web framework functionality.



