# Changelog

## [0.0.1-pre+2] - 2024-05-30

### Downgraded Test Dependency
- Downgraded test package dependency to 1.25.2 to maintain flutter compatibility.

## [0.0.1-pre+1] - 2024-05-11

### Added
- Added Lints Package to streaming testing toolset in the framework.

## [0.0.1-pre] - 2024-04-14

### Added
- Initial release with testing framework functionality.



