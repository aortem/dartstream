# Changelog

## 0.0.1-pre+4

- update shelf based dependencies
- added shelf packages handler in pubspec

## 0.0.1-pre+3

- update formatting of pubspec.yaml

## 0.0.1-pre+2

- update pubspec.yaml to use latest testing package

## 0.0.1-pre+1

- update Shelf web socket to: ^1.0.4
- update Build Runner to: ^2.4.9

## 0.0.1-pre

### Added
- Initial release with core shelf framework functionality.



