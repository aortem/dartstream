// lib/ds_middleware.dart

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'config/ds_ config.dart';
import 'core/ds_middleware.dart';
import 'core/ds_request.dart';
import 'core/ds_router.dart';
import 'handlers/ds_auth_handler.dart';
import 'handlers/ds_body_parser.dart';
import 'handlers/ds_cors_handler.dart';
import 'handlers/ds_csrf_protection.dart';
import 'handlers/ds_error_handler.dart';

class DSMiddleware {
  final Router router = Router();
  final Middleware middleware = Middleware();

  DSMiddleware() {
    _initializeHandlers();
  }

  void _initializeHandlers() {
    // Attach necessary middleware handlers
    middleware.use(ErrorHandler());
    middleware.use(AuthHandler());
    middleware.use(BodyParser());
    middleware.use(CorsHandler());
    middleware.use(CSRFProtection());

    // Set up routes
    Config.routes.forEach((route) {
      router.addRoute(route['path'], route['handler']);
    });
  }

Future<void> handleRequest(HttpRequest httpRequest) async {
  // Convert HttpHeaders to a Map<String, dynamic>
  final headersMap = <String, dynamic>{};
  httpRequest.headers.forEach((name, values) {
    headersMap[name] = values.join(', ');
  });

  // Convert HttpRequest to your Request object
  final request = DsMiddlewareRequest(
    path: httpRequest.uri.path,
    method: httpRequest.method,
    headers: headersMap,
  //  body: await httpRequest.transform(utf8.decoder as StreamTransformer<List<int>, String>).join(),

  );

  // Process the request through middleware
  final response = await middleware.process(request);
  
  // Send response
  httpRequest.response
    ..statusCode = response.statusCode
    ..write(response.body)
    ..close();
}
  // Function to start the server
  Future<void> startServer({String host = 'localhost', int port = 8080}) async {
    final server = await HttpServer.bind(host, port);
    print('Server running on http://$host:$port/');

    await for (HttpRequest httpRequest in server) {
      await handleRequest(httpRequest);
    }
  }
}
