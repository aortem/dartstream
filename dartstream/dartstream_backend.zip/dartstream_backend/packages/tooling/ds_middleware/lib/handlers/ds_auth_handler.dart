// lib/handlers/auth_handler.dart
import '../core/ds_middleware.dart';
import '../core/ds_request.dart';
import '../core/ds_response.dart';


class AuthHandler extends MiddlewareHandler {
  @override
  Future<void> handle(DsMiddlewareRequest request, DsMiddlewareResponse response) async {
    if (!request.headers.containsKey('Authorization')) {
      response.statusCode = 401;
      response.body = 'Unauthorized';
      response.complete();
    }
  }
}
