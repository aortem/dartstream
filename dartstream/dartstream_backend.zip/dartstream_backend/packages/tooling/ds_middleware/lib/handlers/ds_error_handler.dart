// lib/handlers/error_handler.dart
import '../core/ds_middleware.dart';
import '../core/ds_request.dart';
import '../core/ds_response.dart';


class ErrorHandler extends MiddlewareHandler {
  @override
  Future<void> handle(DsMiddlewareRequest request, DsMiddlewareResponse response) async {
    if (response.statusCode == 404) {
      response.body = '404: Not Found';
      response.complete();
    }
  }
}
