// lib/handlers/cors_handler.dart

import '../core/ds_middleware.dart';
import '../core/ds_request.dart';
import '../core/ds_response.dart';

class CorsHandler extends MiddlewareHandler {
  @override
  Future<void> handle(DsMiddlewareRequest request, DsMiddlewareResponse response) async {
    response.headers['Access-Control-Allow-Origin'] = '*';
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  }
}
