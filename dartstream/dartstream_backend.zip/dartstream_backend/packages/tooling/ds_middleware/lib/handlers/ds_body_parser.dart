// lib/handlers/body_parser.dart


import '../core/ds_middleware.dart';
import '../core/ds_request.dart';
import '../core/ds_response.dart';

class BodyParser extends MiddlewareHandler {
  @override
  Future<void> handle(DsMiddlewareRequest request, DsMiddlewareResponse response) async {
    // Parse JSON or other body formats
    if (request.headers['Content-Type'] == 'application/json') {
      request.body = _parseJson(request.body);
    }
  }

  dynamic _parseJson(dynamic body) {
    // Basic JSON parsing (expand as needed)
    return body; // Placeholder for JSON parsing logic
  }
}
