import 'dart:convert';
import 'dart:io';

import 'ds_request.dart';

class DsMiddlewareResponse {
  int statusCode;
  String statusMessage;
  final Map<String, String> headers = {};
  dynamic body;
  bool isChunked = false;
  Stream<List<int>>? stream;
  bool isComplete = false;

  void complete() => isComplete = true;

  DsMiddlewareResponse(
      {this.statusCode = 200, this.statusMessage = "OK", this.body});

  // 1. Status Codes
  void setStatus(int code, String message) {
    statusCode = code;
    statusMessage = message;
  }

  static DsMiddlewareResponse ok(dynamic content) =>
      DsMiddlewareResponse(statusCode: 200, body: content);
  static DsMiddlewareResponse notFound([dynamic content = 'Not Found']) =>
      DsMiddlewareResponse(statusCode: 404, body: content);

  // 2. Headers
  void setHeader(String key, String value) {
    headers[key] = value;
  }

  // 3. Body Content
  void setBody(dynamic content) {
    if (content is String) {
      setHeader('Content-Type', 'text/plain');
      body = content;
    } else if (content is Map || content is List) {
      setHeader('Content-Type', 'application/json');
      body = jsonEncode(content);
    } else if (content is List<int>) {
      setHeader('Content-Type', 'application/octet-stream');
      body = content; // Binary data
    }
  }

  // 4. Content Negotiation
  void negotiateContent(
      DsMiddlewareRequest request, Map<String, dynamic> options) {
    final accepted = request.headers['Accept'] ?? 'text/plain';
    if (options.containsKey(accepted)) {
      setBody(options[accepted]);
      setHeader('Content-Type', accepted);
    } else {
      setBody(options['default']);
      setHeader('Content-Type', 'text/plain');
    }
  }

  // 5. File Downloads and Streaming
  void downloadFile(String filePath, {String? filename}) {
    final file = File(filePath);
    if (!file.existsSync()) {
      setStatus(404, 'File Not Found');
      setBody('The requested file was not found on the server.');
    } else {
      filename ??= file.uri.pathSegments.last;
      setHeader('Content-Disposition', 'attachment; filename="$filename"');
      setHeader('Content-Type', 'application/octet-stream');
      stream = file.openRead();
    }
  }

  // 6. Error Handling
  void setError(int code, String message, [dynamic details]) {
    setStatus(code, message);
    setBody({'error': message, 'details': details ?? ''});
    setHeader('Content-Type', 'application/json');
  }

  // 7. CORS Headers
  void setCors(
      {String origin = '*',
      String methods = 'GET,POST,PUT,DELETE',
      String headers = '*'}) {
    setHeader('Access-Control-Allow-Origin', origin);
    setHeader('Access-Control-Allow-Methods', methods);
    setHeader('Access-Control-Allow-Headers', headers);
  }

  // 8. Caching
  void setCache({String cacheControl = 'no-cache', DateTime? expires}) {
    setHeader('Cache-Control', cacheControl);
    if (expires != null) {
      setHeader('Expires', HttpDate.format(expires.toUtc()));
    }
  }

  // 9. Compression
  void enableCompression() {
    setHeader('Content-Encoding', 'gzip');
    // Note: Actual gzip compression logic should be added here based on server implementation
  }

  // 10. Chunked Responses
  void enableChunkedResponse(Stream<List<int>> chunkStream) {
    isChunked = true;
    stream = chunkStream;
    setHeader('Transfer-Encoding', 'chunked');
  }
}

// Example Usage
void main() {
  // Create a basic 200 OK response
  final response = DsMiddlewareResponse.ok({'message': 'Success'});

  // Set a custom header
  response.setHeader('X-Custom-Header', 'custom-value');

  // Enable CORS
  response.setCors();

  // Set Cache-Control headers
  response.setCache(cacheControl: 'public, max-age=3600');

  // Enable compression
  response.enableCompression();

  // Print response details
  print('Status: ${response.statusCode} ${response.statusMessage}');
  print('Headers: ${response.headers}');
  print('Body: ${response.body}');
}
