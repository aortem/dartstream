// lib/core/request.dart
import 'dart:convert';

class DsMiddlewareRequest {
  final String path;
  final String method; // New method property
  final Map<String, dynamic> headers;
  dynamic body;

  DsMiddlewareRequest({
    required this.path,
    required this.method, // Require method as a parameter
    this.headers = const {},
    this.body,
  });

  // Method to add a new header
  void addHeader(String key, dynamic value) {
    headers[key] = value;
  }

  // Method to check if a specific header exists
  bool hasHeader(String key) {
    return headers.containsKey(key);
  }

  // Method to retrieve a specific header's value
  dynamic getHeader(String key) {
    return headers[key];
  }

  // Method to parse body as JSON (if it's in JSON format)
  Map<String, dynamic>? get jsonBody {
    if (headers['Content-Type'] == 'application/json' && body is String) {
      try {
        return jsonDecode(body);
      } catch (e) {
        print('Error decoding JSON: $e');
        return null;
      }
    }
    return null;
  }

  // Method to update or set the body
  void setBody(dynamic newBody) {
    body = newBody;
  }

  // Method to check if the request method matches a specified method
  bool isMethod(String methodToCheck) {
    return method.toUpperCase() == methodToCheck.toUpperCase();
  }
}
