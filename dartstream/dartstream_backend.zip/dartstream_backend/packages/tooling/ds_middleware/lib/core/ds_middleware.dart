// lib/core/middleware.dart


import 'ds_request.dart';
import 'ds_response.dart';

abstract class MiddlewareHandler {
  Future<void> handle(DsMiddlewareRequest request, DsMiddlewareResponse response);
}

class Middleware {
  final List<MiddlewareHandler> _handlers = [];

  void use(MiddlewareHandler handler) => _handlers.add(handler);

  Future<DsMiddlewareResponse> process(DsMiddlewareRequest request) async {
    final response = DsMiddlewareResponse();
    for (final handler in _handlers) {
      await handler.handle(request, response);
      if (response.isComplete) break;
    }
    return response;
  }
}
