// lib/core/router.dart

import 'ds_request.dart';
import 'ds_response.dart';

class Router {
  final Map<String, Function(DsMiddlewareRequest, DsMiddlewareResponse)> _routes = {};

  void addRoute(String path, Function(DsMiddlewareRequest, DsMiddlewareResponse) handler) {
    _routes[path] = handler;
  }

  void routeRequest(DsMiddlewareRequest request, DsMiddlewareResponse response) {
    final handler = _routes[request.path];
    if (handler != null) {
      handler(request, response);
    } else {
      response.statusCode = 404;
      response.body = 'Route not found';
    }
  }
}
