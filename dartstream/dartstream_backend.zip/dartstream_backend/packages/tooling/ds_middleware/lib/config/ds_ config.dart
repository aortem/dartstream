// lib/config/config.dart


import '../core/ds_request.dart';
import '../core/ds_response.dart';

class Config {
  static final List<Map<String, dynamic>> routes = [
    {
      'path': '/',
      'handler': (DsMiddlewareRequest req, DsMiddlewareResponse res) {
        res.body = 'Welcome to the Home Page!';
      },
    },
    {
      'path': '/about',
      'handler': (DsMiddlewareRequest req, DsMiddlewareResponse res) {
        res.body = 'About Us Page';
      },
    },
    {
      'path': '/api/data',
      'handler': (DsMiddlewareRequest req, DsMiddlewareResponse res) {
        res.body = {'data': 'Sample data from the API'};
      },
    },
  ];
}
