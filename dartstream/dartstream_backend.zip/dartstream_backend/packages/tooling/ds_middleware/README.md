# DartStream

## USMAN TO PROVIDE COMPREHENSIVE README IN ORDER FOR QA to test.
## ie. Step 1, Step 2, Step 3, Step 4 etc etc etc with use cases of what is being tested.

-> First you need to install a DSCustomMiddleware package
-> Install command is dart init ds_custom_middleware
-> You can see a example folder. 
-> In a example, you can see how it use in a dart project. 
-> Also, you can run a test file. 
-> In a test folder, I write a test cases. Please check test case by running a command 
-> dart test



## Licensing

All Dartstream packages are licensed under BSD-3, except for the *services packages*, which uses the ELv2 license, and the *Dartstream SDK packages*, which are licensed from third party software Aortem Inc. In short, this means that you can, without limitation, use any of the client packages in your app as long as you do not offer the SDK's or services as a cloud service to 3rd parties (this is typically only relevant for cloud service providers).  See the [LICENSE](LICENSE.md) file for more details.


## Enhance with DartStream"

We hope DartStream helps you to efficiently build and scale your server-side applications. Join our growing community and start contributing to the ecosystem today!