/*  TBD
- Private Utilities for CLI
- Part Files for CLI
- Internal Implementations for CLI */