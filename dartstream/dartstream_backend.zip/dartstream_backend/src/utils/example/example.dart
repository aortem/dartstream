//Example of How the configuration Loader Might be used in the application

/*import 'src/core/utils/config_loader.dart';

void main(List<String> args) {
  // Assuming configuration files are stored in `config/`
  var config = ConfigLoader.load('config/');
  runApp(config);
}

void runApp(dynamic config) {
  // Start your application with loaded configurations
  print('App running with config: $config');
} */
